#  PROJET 3 ICADEMIE
Projet 3 en collaboration avec: <br>
.....<br>
.....<br>
.....<br>
.....<br>
.....<br>
.....<br>

Création d'un site de cabinet d'avocat. 

# FRAMEWORK JAVASCRIPT
Jquery <br>
BootStrap

# FRAMEWORK PHP 
CodeInginiter 3.1.11 

# PHP VERSION 
PHP 5.5.30 (cli) (built: Sep 30 2015 13:50:53) 

# SERVEUR LOCAL
XAMPP<br>
Windows 10 64 Bit. <br>
Apache 2.4 

