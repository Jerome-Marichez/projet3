<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<h1>Bonjour</h1>
<p>
	Vous voulez savoir ce que nous faisons? Vous êtes sur la bonne page.
</p>
