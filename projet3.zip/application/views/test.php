<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<html>
Bonjour Vous voulez savoir ce que nous savons faire? Vous êtes sur la bonne page. 

</htmL>
