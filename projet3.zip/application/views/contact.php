<div class="container">
	<div class="row" style="margin-top: 50px">
		<div class="col-md-12">
			<h1 style="text-align: center"> CONTACTEZ NOUS</h1>
		</div>

	</div>

	<div class="row" >
		<div class="col-sm-6 col-md-6">
			<div class="text1">
				<p>Vous voulez nous contacter? Remplissez le formulaire</p>
				<form method="post" >
					<div class="form-group">
						<label for="name">Nom</label>
						<input type="text" id="name" class="form-control" >
					</div>
					<div class="form-group">
						<label for="firstname">Prenom</label>
						<input type="text" id="firstname" class="form-control" >
					</div>
					<div class="form-group">
						<label for="mail">mail</label>
						<input type="email" id="mail" class="form-control" >
					</div>
					<div class="form-group">
						<label for="message">message</label>
						<textarea class="form-control" id="message" ></textarea>
					</div>
					<button type="submit" class="btn btn-primary">Envoyer</button>
						</form>
				</div>
			</div>
			<div class="col-sm-6 col-md-6">
				<div class="text1">
					<p>Vous pouvez nous appeler aux heures ouvrables au 05 58 58 59 90</p>
				</div>
				<div class="text2">
					<p>Vous pouvez nous contacter par mail à l'adresse suivante monsite@gmail.com</p>
				</div>
			</div>
		</div>
