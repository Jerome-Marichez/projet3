


			<div class="row" style="margin-top: 50px">
				<div class="galerie col-md-12">
					<h1 style="text-align: center"> BIENVENU SUR NOTRE SITE</h1>
				</div>
			</div>
			<div class="row" style="margin-top: 50px">
				<div class="galerie col-md-12">
					<h1 style="text-align: center"> QUI SOMMES NOUS</h1>
				</div>
			</div>
			<div class="row" style="margin-top: 50px">
				<div class="galerie col-md-12">
					<h1 style="text-align: center"> NOS COMPETENCES</h1>
				</div>
			</div>
			<div class="row" style="margin-top: 50px">
				<div class="galerie col-md-12">
					<h1 style="text-align: center"> NOUS CONTACTER</h1>
				</div>
			</div>
