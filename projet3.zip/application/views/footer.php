<footer class="row">
  <ul class="nav navbar-nav col-md-12">

    <li><a href="conditions-de-vente">Condition générale de vente</a></li>
    <li>copyright©2019</li>
    <li>monsite@gmail.com</li>
  </ul>
</footer>

</div>
